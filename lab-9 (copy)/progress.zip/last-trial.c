#include<pthread.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include "sbuffer.h"
#include "connmgr.h"

#include "sensor_db.h"


int sharedData=0;
pthread_rwlock_t lock;

dplist_t *shared_data;
 pthread_t conn_mgr_thread=0;
pthread_t data_mgr_thread=0;
pthread_t storage_mgr_thread=0;
    

DBCONN * conn;

void *conn_mgr(void *arg)
{

printf("this is the conn manager, running a server\n");
connmgr_listen(1234,&shared_data,&lock);
connmgr_free(&shared_data,&conn);
printf("\n");
exit(0);
return NULL;
}





dplist_t *shared_data;

int main()
{


  
   sbuffer_init(&shared_data);

   pthread_rwlock_init(&lock,NULL);

   
 
    pthread_create(&conn_mgr_thread,NULL,conn_mgr,NULL);
   

  
    pthread_join(conn_mgr_thread,NULL);
   
   
    pthread_rwlock_destroy(&lock);
    
    sbuffer_free(&shared_data);
    disconnect(conn);
 
    return 0;
}